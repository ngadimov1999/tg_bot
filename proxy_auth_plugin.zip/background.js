
            var config = {
                    mode: "fixed_servers",
                    rules: {
                      singleProxy: {
                        scheme: "http",
                        host: "45.136.68.2",
                        port: parseInt(49656)
                      },
                      bypassList: ["localhost"]
                    }
                  };
            
            chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
            
            function callbackFn(details) {
                return {
                    authCredentials: {
                        username: "b3bhNb5jM8",
                        password: "56qw6KBpRI"
                    }
                };
            }
            
            chrome.webRequest.onAuthRequired.addListener(
                        callbackFn,
                        {urls: ["<all_urls>"]},
                        ['blocking']
            );
            